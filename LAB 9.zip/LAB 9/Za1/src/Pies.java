public class Pies extends Animal{
    @Override
    void makeSound() {
        System.out.println("Woof Woof!");
    }
}
