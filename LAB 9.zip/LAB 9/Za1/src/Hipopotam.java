public class Hipopotam extends Animal{

    @Override
    void makeSound() {
        System.out.println("argh argh??");
    }
}
