public class Kot extends Animal{

    @Override
    void makeSound() {
        System.out.println("Miałłł Miałłł ale nie dałłłł");
    }
}
