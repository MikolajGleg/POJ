package pl.edu.pjatk.paymentMethods;

public class Wallet extends PaymentMethod{
    public Wallet(double funds) {
        super(funds);
    }
}
