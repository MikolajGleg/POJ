package pl.edu.pjatk;

public class Silnik {
}
