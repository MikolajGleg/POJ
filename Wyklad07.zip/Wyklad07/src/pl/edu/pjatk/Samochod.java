package pl.edu.pjatk;

public class Samochod extends Pojazd{
    public Samochod(Silnik silnik) {
        super(silnik);
    }
}
