package pl.edu.pjatk;

public class Kwadrat extends Ksztalt{
    private double a;

    public Kwadrat(double a) {
        this.a = a;
    }

    @Override
    public double getArea() {
        return a*a;
    }

    @Override
    public double getPerimeter() {
        return 4*a;
    }

}
