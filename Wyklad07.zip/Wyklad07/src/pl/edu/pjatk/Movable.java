package pl.edu.pjatk;


public interface Movable {

    public abstract void move();

}
