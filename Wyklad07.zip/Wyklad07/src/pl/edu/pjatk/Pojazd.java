package pl.edu.pjatk;

public class Pojazd {
    Silnik silnik;

    public Pojazd(Silnik silnik) {
        this.silnik = silnik;
    }
}
