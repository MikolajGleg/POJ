package pl.edu.pjatk;

public class Prostokąt extends Ksztalt {
    public static int liczbaBokow = 4;
    public double a;
    public double b;

    public Prostokąt(double a, double b) {
        this.a = a;
        this.b = b;
    }

    @Override
    public double getArea() {
        return a * b;
    }

    @Override
    public double getPerimeter() {
        return 2 * a + 2 * b;
    }

}
