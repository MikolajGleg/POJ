package pl.edu.pjatk;

public class SymulatorFarby {
    public static int obliczZapotrzebowanieNaFarbe(Ksztalt[] ksztaltyDoMalowania, double iloscFarby) {
        double sum = 0;
        for (Ksztalt ksztalt : ksztaltyDoMalowania) {
            sum += ksztalt.getArea();
        }

        return (int) Math.ceil(sum / iloscFarby);
    }
}
