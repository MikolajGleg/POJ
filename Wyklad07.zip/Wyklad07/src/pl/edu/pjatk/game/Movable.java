package pl.edu.pjatk.game;

public interface Movable {
    void move();



}
