package pl.edu.pjatk.game;

public class Character {
    int hitpoints;
    int mana;

}
