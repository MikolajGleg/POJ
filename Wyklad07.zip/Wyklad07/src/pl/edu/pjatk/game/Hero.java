package pl.edu.pjatk.game;

public class Hero extends Character implements Movable{
    @Override
    public void move() {

    }
}
