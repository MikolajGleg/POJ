package pl.edu.pjatk.game;

public class Monster implements Killable, Movable {
    int hitpoints;
    int experienceValue;

    @Override
    public void die() {

    }

    @Override
    public void move() {

    }
}
