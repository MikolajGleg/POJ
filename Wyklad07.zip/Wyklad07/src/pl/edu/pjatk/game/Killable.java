package pl.edu.pjatk.game;

public interface Killable {
    void die();
}
