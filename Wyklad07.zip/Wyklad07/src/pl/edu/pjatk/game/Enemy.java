package pl.edu.pjatk.game;

public class Enemy extends Character implements Killable, Movable {


    @Override
    public void die() {

    }

    @Override
    public void move() {

    }
}
