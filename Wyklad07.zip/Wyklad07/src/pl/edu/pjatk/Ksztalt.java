package pl.edu.pjatk;

public abstract class Ksztalt {

    public abstract double getArea();

    public abstract double getPerimeter();

    public final double returnDouble() {
        return 2.0;
    }
}
