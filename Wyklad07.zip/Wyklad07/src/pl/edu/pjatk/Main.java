package pl.edu.pjatk;

import pl.edu.pjatk.game.Killable;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Kwadrat kwadrat = new Kwadrat(4);
        Prostokąt prostokąt = new Prostokąt(2,4);
        Kolo kolo = new Kolo(4);

        Ksztalt[] ksztalty = {kwadrat, prostokąt, kolo};

        System.out.println(SymulatorFarby.obliczZapotrzebowanieNaFarbe(ksztalty, 20));
        wydrukuj("Ala", "ma", "kota");

        Movable[] tab = new Movable[2];

        Killable[] tab1 = new Killable[3];


    }

    public static void wydrukuj(String... argumenty) {
        for (String s : argumenty) {
            System.out.println(s);
        }
    }

    public static int kalkuluj(int... inty) {
        int sum = 0;
        for (int i : inty) {
            sum+= i;
        }

        return sum;
    }

    public static void teleport(Movable object) {
        object.move();
    }
}
