package pl.edu.pjatk;

public class Kolo extends Ksztalt{

    private final double r;

    public Kolo(double r) {
        this.r = r;
    }

    @Override
    public double getArea() {
        return Math.PI * r* r;
//        return Math.PI * Math.pow(r,2);
    }

    @Override
    public double getPerimeter() {
        return 2* Math.PI * r;
    }


}
