package pl.edu.pjatk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main2 {
    public static void main(String[] args) {
        HashMap<String, ArrayList<String>> mapa = new HashMap<>();
        ArrayList<String> lista = new ArrayList<>();
        lista.add("sadassa");

        mapa.put("abc", lista);
        mapa.get("abc").add("asdasda");


        System.out.println(mapa.get("abc"));
    }
}
