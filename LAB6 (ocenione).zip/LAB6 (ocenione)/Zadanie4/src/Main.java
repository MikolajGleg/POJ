public class Main {
    public static void main(String[] args) {
        Produkt produkt = new Produkt("Czekolada Myłka",20,100);
        produkt.toString();
        Produkt produkt1 = new Produkt("Buty Siedmiomilowe",7,777);
        produkt1.toString();
    }
}