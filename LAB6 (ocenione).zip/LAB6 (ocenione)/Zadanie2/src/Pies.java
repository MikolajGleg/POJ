public class Pies {

    public void szczekaj(){
        System.out.println("Woof!");
    }

    public void szczekaj(int sczekajNum){
        for (int i = 0; i < sczekajNum; i++) {
            System.out.println("Woof!");
        }
    }
}
