public class Main {
    public static void main(String[] args) {
        Pies pies = new Pies();
        pies.szczekaj();
        System.out.println("-------");
        pies.szczekaj(6);
    }
}